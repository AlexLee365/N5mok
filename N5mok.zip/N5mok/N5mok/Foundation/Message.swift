//
//  Message.swift
//  N5mok
//
//  Created by Alex Lee on 23/05/2019.
//  Copyright © 2019 hyeoktae kwon. All rights reserved.
//

import Foundation

struct Message{
    var messageKey: String?
    var senderName: String?
    var messageText: String?
    //    var userId: String?
}
